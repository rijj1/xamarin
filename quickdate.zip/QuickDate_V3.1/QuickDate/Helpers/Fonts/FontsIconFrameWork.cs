﻿namespace QuickDate.Helpers.Fonts
{
    public enum FontsIconFrameWork
    {
        IonIcons,
        FontAwesomeSolid,
        FontAwesomeRegular,
        FontAwesomeBrands,
        FontAwesomeLight, 
    } 
}