﻿namespace QuickDate.Library.Anjo.Share.Abstractions
{
	public enum ShareAppControlType
    {
		Link = 0,

		TextInEmail,

		TextInSms,

		TextInMms,

		FileInEmail,

		FileInMessage,

	}
}
