﻿namespace QuickDate.Helpers.ShimmerUtils
{ 
    public enum ShimmerTemplateStyle
    {
        UserProfileTemplate = 0, 
    }
}