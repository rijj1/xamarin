﻿namespace QuickDate.Activities.Chat.ChatBoxStates
{
    public enum ChatBoxButtonWindowState
    {
        AllClosed,
        ShowImages,
        ShowStrickers,
        ShowGifts
    }
}